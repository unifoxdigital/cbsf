<header class="header header-style transparent-header sticky-header" style="text-align: center">
            <div class="container d-none d-lg-block">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header-inner">
                            <div class="logo">
                                <!-- <a href="index.html">

                                    <img class="bottom" src="images/msi_2.png" alt="logo">
                                </a> -->
                                <div id="fade">
                                    <!-- <img class="booto" src="images/A.png"> -->
                                    <!-- <div class="bottom">
                                        <img src="images/msi_2.png">
                                    </div>
                                    <div class="top">
                                        <img src="images/main_logo.png">
                                    </div> -->
                                    <img class="bottom" src="images/msi_2.png" />
                                    <img class="top" src="images/main_logo.png" />

                                </div>
                                
                            </div>
                            <nav class="menu">
                                <ul>
                                    <li>
                                        <a href="index.php">Home</a>
                                    </li>
                                    <li>
                                        <a href="#">About Us</a>
                                    </li>
                                    <li>
                                        <a href="#">Services</a>
                                    </li>
                                    <li class="cr-dropdown">
                                        <a href="javascript:;">Sister Concerns</a>
                                        <ul>
                                            <li class="cr-sub-dropdown">
                                                <a href="javascript:;">Home</a>
                                                <ul>
                                                    <li>
                                                        <a href="index.html">Home</a>
                                                    </li>
                                                    <li>
                                                        <a href="single.html">Single</a>
                                                    </li>
                                                    <li>
                                                        <a href="contact.html">Contact</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="cr-sub-dropdown">
                                                <a href="javascript:;">Single</a>
                                                <ul>
                                                    <li>
                                                        <a href="index.html">Home</a>
                                                    </li>
                                                    <li>
                                                        <a href="single.html">Single</a>
                                                    </li>
                                                    <li>
                                                        <a href="contact.html">Contact</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li class="cr-sub-dropdown">
                                                <a href="javascript:;">Contact</a>
                                                <ul>
                                                    <li>
                                                        <a href="index.html">Home</a>
                                                    </li>
                                                    <li>
                                                        <a href="single.html">Single</a>
                                                    </li>
                                                    <li>
                                                        <a href="contact.html">Contact</a>
                                                    </li>
                                                </ul>
                                            </li>
                                            <li>
                                                <a href="#">FAQ</a>
                                            </li>
                                            <li>
                                                <a href="#">Team</a>
                                            </li>
                                            <li>
                                                <a href="#">Videos</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li class="cr-megamenu">
                                        <a href="javascript:;">Features</a>
                                        <div class="cr-megamenu-wrap">

                                            <!-- Megamenu Single Block -->
                                            <div class="cr-megamenu-single">
                                                <h6>Widget Header</h6>
                                                <ul>
                                                    <li>
                                                        <a href="#">Awesome Features</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Clean Interface</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Responsive Design</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Pixel Perfect Design</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">W3C Validate</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <!--// Megamenu Single Block -->

                                            <!-- Megamenu Single Block -->
                                            <div class="cr-megamenu-single">
                                                <h6>Widget Header</h6>
                                                <ul>
                                                    <li>
                                                        <a href="#">Awesome Features</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Clean Interface</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Responsive Design</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Pixel Perfect Design</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">W3C Validate</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <!--// Megamenu Single Block -->

                                            <!-- Megamenu Single Block -->
                                            <div class="cr-megamenu-single">
                                                <h6>Widget Header</h6>
                                                <ul>
                                                    <li>
                                                        <a href="#">Awesome Features</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Clean Interface</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Responsive Design</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Pixel Perfect Design</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">W3C Validate</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <!--// Megamenu Single Block -->

                                            <!-- Megamenu Single Block -->
                                            <div class="cr-megamenu-single">
                                                <h6>Widget Header</h6>
                                                <ul>
                                                    <li>
                                                        <a href="#">Awesome Features</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Clean Interface</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Responsive Design</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">Pixel Perfect Design</a>
                                                    </li>
                                                    <li>
                                                        <a href="#">W3C Validate</a>
                                                    </li>
                                                </ul>
                                            </div>
                                            <!--// Megamenu Single Block -->
                                            
                                        </div>
                                    </li>
                                    <li>
                                        <a href="contact.html">Contact</a>
                                    </li>
                                </ul>
                            </nav>
                            <!-- <a href="" class="cr-btn cr-btn-sm">
                                <!-- <span></span> -->
                            </a> 
                        </div>
                    </div>
                </div>
            </div>

            <!-- Mobile Menu -->
            <div class="mobile-menu-wrapper">
                <div class="container d-block d-lg-none">
                    <div class="mobile-menu clearfix">
                        <a class="mobile-logo" href="index.html">
                            <img src="images/logo.png" alt="mobile logo">
                        </a>
                        <a href="javascript:;" class="cr-btn cr-btn-sm">
                            <span>Buy now</span>
                        </a>
                    </div>
                </div>
            </div>
            <!-- //Mobile Menu -->

        </header>