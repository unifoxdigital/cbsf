<!DOCTYPE html>
<html>
<head>
	<script type="text/javascript" src="js/package/jquery-1.7.2.min.js"></script>

</head>
<body>
	<div class="fadeImg" >
		<img src="img/cbsf.jpg" />
		<img style="display: none;" src="img/msi.jpg"  />
		<img style="display: none;" src="img/a.jpg" />
	</div>
</body>
</html>