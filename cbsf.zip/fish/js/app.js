$('.carousel').carousel({
  interval: false
});