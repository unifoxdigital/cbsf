<footer id="footer" style="background-color: #039be5">
	<div class="container">
		<div class="row" >

			<div class="col-md-3">
				<div class="contact-details">
					<h4>Address:</h4>
					<ul class="contact">
						<li><p style="color: #fff"><i class="fa fa-map-marker"></i> <strong></strong> Hajee Para, Zhilongja, Main Road, Cox's Bazar, Bangladesh</p></li>

					</ul>
				</div>
			</div>
			<div class="col-md-3">
				<div class="contact-details">
					<h4>Contact Number</h4>
					<ul class="contact">
						<li><p style="color: #fff"><i class="fa fa-phone"></i> <strong>Phone:</strong> +880-341-63396</p></li>
						<li><p style="color: #fff"><i class="fa fa-envelope"></i> <strong>Email:</strong> <a href="mailto:mail@example.com">cbsfsygn@gmail.com</a></p></li>
					</ul>
				</div>
			</div>
			<div class="col-md-3">
				<h4>Important Links</h4>
				<p style="font-size: 15px;color:#fff;font-style:bold;"><a href="http://globe.farmersmarket.asia/login" target="_blank">e-Tracability</a></p>
			</div>
			<div class="col-md-3">
				<h4>Follow Us</h4>
				<ul class="social-icons">
					<li class="social-icons-facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook"><i class="fa fa-facebook"></i></a></li>
					<li class="social-icons-twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter"><i class="fa fa-twitter"></i></a></li>
					<li class="social-icons-linkedin"><a href="http://www.linkedin.com/" target="_blank" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
				</ul>
			</div>

		</div>
	</div>

</footer>